public interface Join {
	void join(Scheme leftRel, Scheme rightRel);
}
